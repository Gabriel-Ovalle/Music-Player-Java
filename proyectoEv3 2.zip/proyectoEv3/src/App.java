import controller.Question;
import controller.Quiz;
import controller.student;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {
    public static void main(String[] args) throws Exception {
        launch(args);
    }
    

    @Override
    public void start(Stage stage) throws Exception {
        //FXMLLoader loader = new FXMLLoader(getClass().getResource("fxml/login2.fxml"));
        createTables();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("fxml/adminScreen.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        // stage.setHeight(750);
        // stage.setWidth(900);
        
        stage.show();

    }
    private void createTables(){
        Quiz.createTable();
        Question.createTable();
        student.createTable();
}
}

