import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import controller.Question;
import controller.Quiz;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.TreeView;
import javafx.scene.control.Alert.AlertType;


public class addQuizController implements Initializable {

    @FXML
    private Alert alerta  = new Alert(AlertType.ERROR);

    @FXML
    private TreeView<?> treeView;
    
    @FXML
    private Button addNextQuestion;

    @FXML
    private TextField option1;

    @FXML
    private TextField option2;

    @FXML
    private TextField option3;

    @FXML
    private TextField option4;

    @FXML
    private TextArea question;

    @FXML
    private TextField quizTitle;

    @FXML
    private RadioButton radio1;

    @FXML
    private RadioButton radio2;

    @FXML
    private RadioButton radio3;

    @FXML
    private RadioButton radio4;

    @FXML
    private Button setQuizTitleButton;

    @FXML
    private Button submitQuiz;

    private ToggleGroup radioGroup;

    //! Mi variable
    private Quiz quiz = null;
    private ArrayList<Question> questions = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        radioButtonSetup();

    }

    private void radioButtonSetup(){
        radioGroup = new ToggleGroup();
        radio1.setToggleGroup(radioGroup);
        radio2.setToggleGroup(radioGroup);
        radio3.setToggleGroup(radioGroup);
        radio4.setToggleGroup(radioGroup);
    }

    @FXML
    void setQuizTitle(ActionEvent event){
        System.out.println("Set quiz title");
        String title = quizTitle.getText();

        if (title.trim().isEmpty()){
            alerta.setTitle("Empty space warning");
            alerta.setHeaderText("Quiz title cannot be empty.");
            alerta.setContentText("Please add a quiz title.");
            alerta.showAndWait();

            System.out.println("Enter a valid quiz title");
            }

        else{
            quizTitle.setEditable(false);
            System.err.println("Save title..");
            this.quiz = new Quiz(title);
        }
    }

    private boolean validate(){

        if(quiz == null){
            alerta.setTitle("Empty space warning");
            alerta.setHeaderText("Quiz");
            alerta.setContentText("Please enter a quiz title.");
            alerta.showAndWait();

            return false;
        }

        String principal = this.question.getText();
        String op1 = this.question.getText();
        String op2 = this.question.getText();
        String op3 = this.question.getText();
        String op4 = this.question.getText();
        Toggle selectedRadio = radioGroup.getSelectedToggle();
        System.out.println(selectedRadio);

        if(principal.trim().isEmpty() || op1.trim().isEmpty() || op2.trim().isEmpty() || op3.trim().isEmpty() || op4.trim().isEmpty()){

            alerta.setTitle("Empty space warning");
            alerta.setHeaderText("The options cannot be empty.");
            alerta.setContentText("Please field all the options.");
            alerta.showAndWait();

            return false;
        }
        else{
            if(selectedRadio == null){
                alerta.setTitle("No select warning");
                alerta.setHeaderText("The options cannot be empty.");
                alerta.setContentText("Please select the correct answer..");
                alerta.showAndWait();

                return false;
            }
            else{
                return true;
            }
        }
        
    }

    @FXML
    void addNextQuestion(ActionEvent event) {
        addQuestions();
    }
    private boolean addQuestions(){
        boolean valid = validate();
        Question question = new Question();
        if(valid){
            question.setOption1(option1.getText().trim());
            question.setOption2(option2.getText().trim());
            question.setOption3(option3.getText().trim());
            question.setOption4(option4.getText().trim());

            Toggle selected = radioGroup.getSelectedToggle();
            String answer = null;

            if (selected == radio1){
                answer = option1.getText().trim();

            }
            else if(selected == radio2){
                answer = option2.getText().trim();
            }
            else if(selected == radio3){
                answer = option3.getText().trim();
            }
            else if(selected == radio4){
                answer = option4.getText().trim();
            }

            question.setAnswer(answer);
            question.setQuestion(this.question.getText().trim());
            
            this.question.clear();
            option1.clear();
            option2.clear();
            option3.clear();
            option4.clear();

            questions.add(question);
            question.setQuiz(quiz);

            System.out.println("Save Question...");
            System.out.println("----------------------");
            System.out.println(questions);
            System.out.println(quiz);
        }
        return valid;
    }

    @FXML
    void submitQuiz(ActionEvent event) {
        boolean flag = addQuestions();

        if(flag){
            flag = quiz.saveQuiz(questions);
            if(flag){
                //! valido
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("Congratulations!!");
                alert.setTitle("SUCCESS");
                alert.setContentText("Quiz successfully saved");
                alert.showAndWait();
            }
            else{
                //! no valido
                alerta.setTitle("FAIL");
                alerta.setHeaderText("There was a mistake");
                alerta.setContentText("Cannot saved the quiz, try again..");
                alerta.showAndWait();
            }
        }
    }

}
