import java.net.URL;
import java.util.ResourceBundle;

import controller.adminLogin;
import controller.studentLogin;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class loginController implements Initializable {

    @FXML
    private Alert alerta  = new Alert(AlertType.ERROR);
    @FXML
    private PasswordField adminPassword;

    @FXML
    private Button adminButton;

    @FXML
    private TextField adminEmail;

    @FXML
    private Button studentButton;

    @FXML
    private TextField studentEmail;

    @FXML
    private PasswordField studentPassword;

    @Override
    public void initialize(URL url, ResourceBundle rb){
        
    }

    @FXML
    void loginAdmin(ActionEvent event) {
        String email = adminEmail.getText();
        String password = adminPassword.getText();

        if(email.trim().equalsIgnoreCase(adminLogin.email) && password.trim().equalsIgnoreCase(adminLogin.password)){
            
            try {
                Parent root = FXMLLoader.load(getClass().getResource("fxml/adminScreen.fxml"));
                Stage stage = (Stage) studentPassword.getScene().getWindow();
                Scene scene = new Scene(root);
                Stage newStage = new Stage();
                newStage.setScene(scene);

                newStage.setOnCloseRequest(closeEvent -> {
                    stage.show();
                });

                stage.hide();
                // newStage.setMaximized(true);
                // newStage.setFullScreen(true);
                newStage.show();
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(0);
            }
            System.out.println("Login success");
        }
        else{
            System.out.println("Login Failed");
        }
        System.out.println("AdminContoller.loginAdmin()");
                        
    }

    @FXML
    void loginStudent(ActionEvent event) {
        String email2 = studentEmail.getText();
        String password2 = studentPassword.getText();

        if (email2.trim().equalsIgnoreCase(studentLogin.email2) && password2.trim().equalsIgnoreCase(studentLogin.password2)) {
            System.out.println("Login success");

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("Congratulations!!");
                alert.setTitle("SUCCESS");
                alert.setContentText("Quiz successfully saved");
                alert.showAndWait();
        }
        
        else {
            System.out.println("Login Failed");
                alerta.setHeaderText("Something its wrong");
                alerta.setTitle("login could not be completed");
                alerta.setContentText("Try again..");
                alerta.showAndWait();
        }
        
        System.out.println("AdminContoller.loginAdmin()");
    }

}
