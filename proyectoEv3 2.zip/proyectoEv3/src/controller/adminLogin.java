package controller;
public class adminLogin{
    public static String email = "admin@gmail.com";
    public static String password = "12345";
}
