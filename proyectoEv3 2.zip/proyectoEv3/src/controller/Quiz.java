package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;



public class Quiz {
    private Integer quizId;
    private String title;

    //constructores
    public Quiz(String title){
        this.title = title;
    }

    public static class MetaData{
        public static final String TABLE_NAME = "quizes";
        public static final String QUIZ_ID = "quiz_id";
        static final String TITLE = "title";
    }

    public Quiz(){

    }

    public Integer getQuizId(){
        return quizId;
    }
    public String getTitle(){
        return title;
    }
    public void setQuizId(Integer quizId){
        this.quizId = quizId;
    }
    public void setQuizTitle(String title){
        this.title = title;
    }

    @Override
    public String toString(){
        return "Quiz{" + "quizId=" + quizId + ", title= " + title + "}";
    }
    //!SQL
    public static void createTable(){
        try{
        String table = "CREATE TABLE %s (%s INTEGER PRIMARY KEY AUTOINCREMENT, %s VARCHAR(50));";
        String query = String.format(table, MetaData.TABLE_NAME, MetaData.QUIZ_ID, MetaData.TITLE);
        System.err.println(query);
        String conectionURL = "jdbc:sqlite:quiz.db";
        Class.forName("org.sqlite.JDBC");
        Connection connection = DriverManager.getConnection(conectionURL);
        PreparedStatement ps = connection.prepareStatement(query);
        boolean b = ps.execute();
        System.out.println("models.quiz.createTable()");
        System.out.println(b);
        connection.close();

        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        
    }
    public int saveQuiz(){
        String table = "insert into %s (%s) values (?)";
            String query = String.format(table, MetaData.TABLE_NAME, MetaData.TITLE);
            String conectionURL = "jdbc:sqlite:quiz.db";
        try{
            Class.forName("org.sqlite.JDBC");

            try(Connection connection = DriverManager.getConnection(conectionURL);){

                PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, this.title);
                int i = ps.executeUpdate();
                ResultSet keys = ps.getGeneratedKeys();

                if(keys.next()){
                    return keys.getInt(1);

            }
    
            }
        }
            catch(Exception ex){
                ex.printStackTrace();
                return -1;
            }
            return -1;

    }
    public boolean saveQuiz(ArrayList<Question> questions){
        boolean flag = true;
        this.quizId = this.saveQuiz();
        
        for(Question q: questions){
            flag = flag && q.saveQuestion();
            System.out.println(flag);
        }
        return flag;
    }

}