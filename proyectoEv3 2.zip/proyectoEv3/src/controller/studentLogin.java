package controller;

public class studentLogin {
        public static String email2 = "admin@gmail.com";
        public static String password2 = "12345";
        

}
