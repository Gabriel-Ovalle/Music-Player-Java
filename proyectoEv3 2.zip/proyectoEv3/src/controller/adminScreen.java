package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

public class adminScreen implements Initializable{

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
    
}
