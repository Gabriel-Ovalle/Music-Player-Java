package controller;

//import java.util.regex.Pattern;

public class test {
    public static void main(String[] args) {
        //student.createTable();

        //! verificacion de estudiante
        //System.out.println("listo");
        // boolean b = new student("Juan", "Hernandez", "juan@gmail.com", 'm', "7896")
        // .studentExists();
        // System.out.println(b);

        //! guardar pregunta
       // Quiz quiz= new Quiz("math quiz");
        //quiz.setQuizId(quiz.saveQuiz());
        //Question question = new Question(quiz, "3", "2", "4", "5", "6", "5");
        //question.saveQuestion();

        //! validacion de email
        //Pattern p = Pattern.compile("^\\w+[a-zA-Z_]+?\\.[a-zA-Z]{2,3}$");
        //System.out.println(p.matcher("marta68@gmail.com").matches());
        //System.out.println(p.matcher("juanaperez34@gmail.com").matches());
        //System.out.println(p.matcher("martaJimenez68@gmail").matches());
        //System.out.println(p.matcher("martaJimenegmail.com").matches());

        //System.out.println(student.getAll());
        //System.out.println(student.getAll().size());
    }
}
