package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class student {
    private Integer id;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private Character gender;

    private static class metaData{
        public static final String TABLE_NAME = "students";
        public static final String ID = "id";
        public static final String FIRST_NAME = "firstName";
        public static final String LAST_NAME = "lastName";
        public static final String EMAIL = "email";
        public static final String PASSWORD = "password";
        public static final String GENDER = "gender";
        
    }

public student(String firstName, String lastName, String email,String password, Character gender){
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.password = password;
    this.gender = gender;

}
public student(){

}
public student(Integer id, String firstName, String lastName, String email, String password, Character gender){
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.password = password;
    this.gender = gender;

}

@Override
public String toString(){
    return "Student{" + "id = " + id + ", first name = "+ firstName + " lastname = " + lastName +
    " email = " + email + " gender= " + gender + " password = " + password  + "}";

}
//! set
public void setId(Integer id){
    this.id = id;
}
public void setFirstName(String firstName){
    this.firstName = firstName;
}
public void setLastName(String lastName){
    this.lastName = lastName;
}
public void setEmail(String email){
    this.email = email;
}
public void setGender(Character gender){
    this.gender = gender;
}
public void setPassword(String password){
    this.password = password;
}

//! get
public Integer getId(){
    return id;
}
public String getFirstName(){
    return firstName;
}
public String getLastName(){
    return lastName;
}
public String getEmail(){
    return email;
}
public Character getGender(){
    return gender;
}
public String getPassword(){
    return password;
}

//! sql table

public static void createTable(){
    String table = "CREATE TABLE IF NOT EXISTS %s(" +
        "%s INTEGER PRIMARY KEY AUTOINCREMENT," +
        "%s VARCHAR(20)," +
        "%s VARCHAR(20)," +
        "%s VARCHAR(50)," +
        "%s VARCHAR(20),"+
        "%s CHAR)";

    String query = String.format(table,metaData.TABLE_NAME, metaData.ID, metaData.FIRST_NAME, metaData.LAST_NAME,
    metaData.EMAIL, metaData.PASSWORD, metaData.GENDER);

    System.out.println(query);

    try{
        String conectionURL = "jdbc:sqlite:quiz.db";
        Class.forName("org.sqlite.JDBC");
        Connection connection = DriverManager.getConnection(conectionURL);
        PreparedStatement ps = connection.prepareStatement(query);
        boolean b = ps.execute();
        System.out.println("models.student.createTable()");
        System.out.println(b);

        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }

    //! Guardar estudiante
    public student saveStudent(){
        String table = "INSERT INTO %s (%s,%s,%s,%s,%s) VALUES (?, ?, ?,  ?, ?);";

        String query = String.format(table, metaData.TABLE_NAME ,metaData.FIRST_NAME, metaData.LAST_NAME,
    metaData.EMAIL, metaData.GENDER, metaData.PASSWORD);

    System.err.println("Query = " + query);
    String conectionURL = "jdbc:sqlite:quiz.db";

        try{
            Class.forName("org.sqlite.JDBC");
        try(Connection connection = DriverManager.getConnection(conectionURL)){
            PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, this.firstName);
            ps.setString(2, this.lastName);
            ps.setString(3, this.email);
            ps.setString(4, this.password);
            ps.setString(5, String.valueOf(this.gender));
            int i = ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                this.id = keys.getInt(1);
            }
            System.out.println("Rows: " + i);
            return this;
        }
        } catch (Exception e) {
        }
        return null;
    }

    //! recoge todos los estudiantes de sql
    public  static ArrayList<student> gettAll(){
        ArrayList<student> students = new ArrayList<>();

        String query = String.format("SELECT %s, " +
        "%s, "+
        "%s, " + 
        "%s, "+ 
        "%s, " + "%s fROM %s;",
        metaData.ID, metaData.FIRST_NAME, metaData.LAST_NAME,
    metaData.EMAIL, metaData.PASSWORD, metaData.GENDER, metaData.TABLE_NAME);

    System.err.println("Query = " + query);
    String conectionURL = "jdbc:sqlite:quiz.db";

        try{
            Class.forName("org.sqlite.JDBC");
        try(Connection connection = DriverManager.getConnection(conectionURL)){
            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet result = ps.executeQuery();
            while(result.next()) {
                student s = new student();
                s.setId(result.getInt(1));
                s.setFirstName(result.getString(2));
                s.setLastName(result.getString(3));
                s.setEmail(result.getString(4));
                s.setPassword(result.getString(6));
                s.setGender(result.getString(5).charAt(0));

                students.add(s);
            };
        }
        } catch (Exception e) {
        }
        return students;
    }

    //! reconocer si el estudiante existe
    public boolean studentExists(){

        String query = String.format("SELECT * FROM %s WHERE %s = ?;", metaData.TABLE_NAME, metaData.EMAIL);

    System.err.println("Query = " + query);
    String conectionURL = "jdbc:sqlite:quiz.db";

        try{
            Class.forName("org.sqlite.JDBC");
        try(Connection connection = DriverManager.getConnection(conectionURL)){
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, this.email);
            ResultSet result = ps.executeQuery();
            if (result.next()) {
                return true;
            };
        }
        } catch (Exception e) {
        }
        return false;
    }

}
