

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import controller.student;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

public class adminStudentTabController implements Initializable{

    @FXML
    private Alert alerta  = new Alert(AlertType.ERROR);

    @FXML
    private TableColumn<student, String> ColumnEmail;

    @FXML
    private TableColumn<student, String> ColumnFirstName;

    @FXML
    private TableColumn<student, Character> ColumnGender;

    @FXML
    private TableColumn<student, String> ColumnLastName;

    @FXML
    private TableColumn<student, String> ColumnPassword;

    @FXML
    private TableView<student> studentTable;

    @FXML
    private TextField FirstName;

    @FXML
    private VBox FormForStudent;

    @FXML
    private TextField LastName;

    @FXML
    private Button SaveStudentButton;

    @FXML
    private TextField StudentEmail;

    @FXML
    private TableColumn<student, String> StudentID;

    @FXML
    private RadioButton female;

    @FXML
    private RadioButton male;

    @FXML
    private RadioButton other;
    @FXML
    private PasswordField password;

    private ToggleGroup toggleGroup;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        initAll();
        radioButtonSetup();
        renderTable();
    }

    //! extrae los valores para la tabla 
    private void renderTable() {
    List<student> students = student.gettAll();
    studentTable.getItems().clear();
    this.StudentID.setCellValueFactory(new PropertyValueFactory <>("id"));
    this.ColumnFirstName.setCellValueFactory(new PropertyValueFactory <>("firstName"));
    this.ColumnLastName.setCellValueFactory(new PropertyValueFactory <>("lastName"));
    this.ColumnEmail.setCellValueFactory(new PropertyValueFactory <>("email"));
    this.ColumnPassword.setCellValueFactory(new PropertyValueFactory <>("password"));
    this.ColumnGender.setCellValueFactory(new PropertyValueFactory <>("gender"));

    studentTable.getItems().addAll(students);
}

    private void radioButtonSetup() {
        this.male.setSelected(true);
        this.male.setToggleGroup(toggleGroup);
        this.female.setToggleGroup(toggleGroup);
    }

    private void initAll(){
        toggleGroup = new ToggleGroup();
    }
    private void clearForm(){
        this.FirstName.clear();
        this.LastName.clear();
        this.StudentEmail.clear();
        this.password.clear();

    }

    @FXML
    public void saveStudent(ActionEvent event) {
        System.out.println("Button Clicked...");
        
        String firstName = this.FirstName.getText();
        String lastName = this.LastName.getText();
        String email = this.StudentEmail.getText().trim();
        String password = this.password.getText().trim();
        Character gen = 'M';
        RadioButton gender = (RadioButton)toggleGroup.getSelectedToggle();
        if(gender != null){
            if(gender == female){
                gen = 'F';
            }
        }

        String message = null;
        Pattern p = Pattern.compile("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$");

        if(firstName.length()<4){
            message = "The name must be more than 4 characters long";
        }
        else if(lastName.length()<2){
            message ="The last name must be more than 2 characters long";
        }
        else if(!p.matcher(email).matches()){
            message = "Enter a valid email";
        }
        else if(password.length()< 6){
            message = "The password must be more than 6 characters long";
        }
        if(message != null){
            alerta.setTitle("Fill the Student form correctly");
            alerta.setHeaderText("Something its wrong");
            alerta.setContentText(message);
            alerta.showAndWait();

            return;
        }
        //! guardar estudiante
        student s = new student(firstName, lastName, email, password, gen);
        System.out.println(s);
        if(s.studentExists()){
            alerta.setTitle("Something its wrong");
            alerta.setHeaderText("The student its already registered");
            alerta.setContentText(message);
            alerta.showAndWait();
            return;
        }
        s = s.saveStudent();
        System.out.println(s);

        if (s != null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("Congratulations!!");
            alert.setTitle("SUCCESS");
            alert.setContentText("Student successfully registered");
            alert.showAndWait();
            this.clearForm();
            studentTable.getItems().add(0, s);
        }
        else{
            alerta.setTitle("Student registration failed");
            alerta.setHeaderText("Something its wrong");
            alerta.setContentText(message);
            alerta.showAndWait();
        }
    }

}
